import Panel from './components/Panel'
import { useGetConfigQuery } from './features/fs/api'
import { PromptProvider } from './ui/PromptDialog'

export default function App() {
  const { data: config } = useGetConfigQuery()

  return (
    <PromptProvider>
      <div className="app">
        <header className="app-header">
          <span className="brand">Web Disk Manager</span>
          <span className="app-hint">
            {config ? `OpenList: ${config.openlistUrl}${config.hasToken ? '' : '（未配置令牌）'}` : ''}
          </span>
          <span className="app-keys">
            F2 重命名 · F3 刷新 · F5 复制 · F6 移动 · F7 新建目录 · F8 删除 · Tab 切换面板
          </span>
        </header>
        <main className="panes">
          <Panel side="left" />
          <Panel side="right" />
        </main>
      </div>
    </PromptProvider>
  )
}

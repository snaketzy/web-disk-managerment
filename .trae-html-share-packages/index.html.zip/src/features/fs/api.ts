import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react'
import type { FsGetResponse, FsListResponse, OpResult, StorageItem } from '../../types'

interface StoragesResponse {
  code: number
  message: string
  storages: StorageItem[]
}

export const api = createApi({
  reducerPath: 'api',
  baseQuery: fetchBaseQuery({ baseUrl: '/api' }),
  tagTypes: ['List', 'Storages'],
  endpoints: (builder) => ({
    getConfig: builder.query<{ openlistUrl: string; hasToken: boolean }, void>({
      query: () => 'config',
    }),
    getStorages: builder.query<StoragesResponse, void>({
      query: () => 'storages',
      providesTags: ['Storages'],
    }),
    listFiles: builder.query<FsListResponse, { path: string; refresh?: boolean }>({
      query: ({ path, refresh }) => ({
        url: 'fs/list',
        params: { path, refresh: refresh ? 1 : 0 },
      }),
      providesTags: ['List'],
    }),
    getFile: builder.query<FsGetResponse, string>({
      query: (path) => ({ url: 'fs/get', params: { path } }),
    }),
    mkdir: builder.mutation<OpResult, { path: string }>({
      query: (body) => ({ url: 'fs/mkdir', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    rename: builder.mutation<OpResult, { path: string; name: string }>({
      query: (body) => ({ url: 'fs/rename', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    remove: builder.mutation<OpResult, { dir: string; names: string[] }>({
      query: (body) => ({ url: 'fs/remove', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    copy: builder.mutation<OpResult, { src_dir: string; dst_dir: string; names: string[] }>({
      query: (body) => ({ url: 'fs/copy', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    move: builder.mutation<OpResult, { src_dir: string; dst_dir: string; names: string[] }>({
      query: (body) => ({ url: 'fs/move', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    newFile: builder.mutation<OpResult, { path: string }>({
      query: (body) => ({ url: 'fs/newfile', method: 'POST', body }),
      invalidatesTags: ['List'],
    }),
    putFile: builder.mutation<OpResult, { dir: string; file: File }>({
      query: ({ dir, file }) => {
        const form = new FormData()
        form.append('dir', dir)
        form.append('name', file.name)
        form.append('file', file)
        return { url: 'fs/upload', method: 'POST', body: form }
      },
      invalidatesTags: ['List'],
    }),
  }),
})

export const {
  useGetConfigQuery,
  useGetStoragesQuery,
  useListFilesQuery,
  useGetFileQuery,
  useLazyGetFileQuery,
  useMkdirMutation,
  useRenameMutation,
  useRemoveMutation,
  useCopyMutation,
  useMoveMutation,
  useNewFileMutation,
  usePutFileMutation,
} = api

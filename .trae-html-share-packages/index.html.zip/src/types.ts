export type Side = 'left' | 'right'

export interface FsItem {
  name: string
  size: number
  is_dir: boolean
  modified: string
  sign?: string
  type?: number
}

export interface FsListData {
  content: FsItem[] | null
  total: number
}

export interface FsListResponse {
  code: number
  message: string
  data?: FsListData
}

export interface FsGetResponse {
  code: number
  message: string
  data?: {
    name: string
    raw_url: string
    is_dir: boolean
  }
}

export interface StorageItem {
  name: string
  path: string
}

export interface OpResult {
  code: number
  message: string
}

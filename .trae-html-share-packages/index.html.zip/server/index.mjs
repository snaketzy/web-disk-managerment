import 'dotenv/config'
import express from 'express'
import multer from 'multer'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const PORT = Number(process.env.PORT || 3001)
const OPENLIST_URL = (process.env.OPENLIST_URL || 'http://127.0.0.1:5244').replace(/\/+$/, '')
const TOKEN = (process.env.OPENLIST_TOKEN || '').trim()

const app = express()
app.use(express.json({ limit: '16mb' }))

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 2 * 1024 * 1024 * 1024 },
})

const authHeaders = () => (TOKEN ? { Authorization: TOKEN } : {})

async function parseJson(res) {
  const text = await res.text()
  try {
    return JSON.parse(text)
  } catch {
    return { code: res.status, message: text || res.statusText }
  }
}

async function olJson(pathname, body) {
  const res = await fetch(OPENLIST_URL + pathname, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body ?? {}),
  })
  return { status: res.status, json: await parseJson(res) }
}

async function olPut(filePath, buffer) {
  const res = await fetch(OPENLIST_URL + '/api/fs/put', {
    method: 'PUT',
    headers: {
      ...authHeaders(),
      'File-Path': encodeURIComponent(filePath),
      'As-Task': 'false',
      'Content-Type': 'application/octet-stream',
    },
    body: buffer,
  })
  return { status: res.status, json: await parseJson(res) }
}

const joinPath = (dir, name) => `${String(dir).replace(/\/+$/, '')}/${name}` || '/'

function fail(res, e, code = 502) {
  res.status(code).json({ code, message: String(e?.message || e) })
}

// ---- 配置 & 存储列表 -----------------------------------------------------

app.get('/api/config', (_req, res) => {
  res.json({ openlistUrl: OPENLIST_URL, hasToken: !!TOKEN })
})

app.get('/api/storages', async (_req, res) => {
  try {
    const { json } = await olJson('/api/fs/list', { path: '/', page: 1, per_page: 0, refresh: false })
    let storages = (json.data?.content || [])
      .filter((i) => i.is_dir)
      .map((i) => ({ name: i.name, path: '/' + i.name }))

    // 兜底：若根目录下没有挂载（存储挂在了子路径），改用管理端存储列表
    if (!storages.length && TOKEN) {
      const admin = await olJson('/api/admin/storage/list', {})
      const list = admin.json.data?.content || []
      const seen = new Set()
      storages = list
        .filter((s) => typeof s.mount_path === 'string' && s.mount_path.startsWith('/'))
        .map((s) => ({ name: s.mount_path.replace(/^\//, '') || '-', path: s.mount_path }))
        .filter((s) => !seen.has(s.path) && seen.add(s.path))
    }

    res.json({ code: 200, message: 'success', storages })
  } catch (e) {
    fail(res, e)
  }
})

// ---- 文件系统 -------------------------------------------------------------

app.get('/api/fs/list', async (req, res) => {
  try {
    const { status, json } = await olJson('/api/fs/list', {
      path: String(req.query.path || '/'),
      page: 1,
      per_page: 0,
      refresh: req.query.refresh === '1',
    })
    res.status(status).json(json)
  } catch (e) {
    fail(res, e)
  }
})

app.get('/api/fs/get', async (req, res) => {
  try {
    const { status, json } = await olJson('/api/fs/get', { path: String(req.query.path || '/') })
    const raw = json.data?.raw_url
    if (typeof raw === 'string' && raw.startsWith('/')) json.data.raw_url = OPENLIST_URL + raw
    res.status(status).json(json)
  } catch (e) {
    fail(res, e)
  }
})

const forward = (pathname) => async (req, res) => {
  try {
    const { status, json } = await olJson(pathname, req.body)
    res.status(status).json(json)
  } catch (e) {
    fail(res, e)
  }
}

app.post('/api/fs/mkdir', forward('/api/fs/mkdir'))
app.post('/api/fs/rename', forward('/api/fs/rename'))
app.post('/api/fs/remove', forward('/api/fs/remove'))
app.post('/api/fs/copy', forward('/api/fs/copy'))
app.post('/api/fs/move', forward('/api/fs/move'))

app.post('/api/fs/newfile', async (req, res) => {
  const filePath = req.body?.path
  if (!filePath) return fail(res, new Error('path required'), 400)
  try {
    const { status, json } = await olPut(filePath, Buffer.alloc(0))
    res.status(status).json(json)
  } catch (e) {
    fail(res, e)
  }
})

app.post('/api/fs/upload', upload.single('file'), async (req, res) => {
  const dir = String(req.body?.dir || '/')
  const name = String(req.body?.name || req.file?.originalname || '')
  if (!req.file || !name) return fail(res, new Error('file & name required'), 400)
  try {
    const { status, json } = await olPut(joinPath(dir, name), req.file.buffer)
    res.status(status).json(json)
  } catch (e) {
    fail(res, e)
  }
})

// ---- 生产环境托管前端静态资源 --------------------------------------------

const distDir = path.resolve(__dirname, '../dist')
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir))
  app.get('*', (_req, res) => res.sendFile(path.join(distDir, 'index.html')))
}

app.listen(PORT, () => {
  console.log(`[web-disk-managerment] server on http://127.0.0.1:${PORT}`)
  console.log(`[web-disk-managerment] OpenList -> ${OPENLIST_URL} (token: ${TOKEN ? 'set' : 'empty'})`)
})
